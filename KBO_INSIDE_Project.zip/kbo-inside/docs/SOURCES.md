# 데이터 출처와 이용 조건

| 자료 | URL | 사용 방식 및 조건 |
|---|---|---|
| KBO 구단 변천사 | https://www.koreabaseball.com/Kbo/League/TeamHistory.aspx | 2015~2024의 최종 순위 사실을 수작업 전사. 확인일 2026-10-22. 원사이트 All Rights Reserved. 자유 라이선스로 표시하지 않음. 원문 페이지·이미지·로고 재배포 없이 개별 기록 사실과 직접 작성 요약만 포함 |
| 한국어 위키백과 | https://ko.wikipedia.org/w/api.php | 실행 중 선택적으로 검색·본문 수집. CC BY-SA 4.0 등 각 문서 바닥글/이력의 실제 조건 확인. 원문 URL과 제목을 보존하고 문서 ID 포함. 제공 ZIP에 위키 원문은 미포함 |
| 위키 이용 조건 | https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use | 재배포 시 저자 표시·원문/이력 링크·변경 표시·동일조건 등 해당 조건 준수 |
| Chroma 공식 문서 | https://docs.trychroma.com/reference/python/collection | upsert/get/query 인터페이스 참고 |
| LangGraph 공식 문서 | https://reference.langchain.com/python/langgraph/graph/state/StateGraph | StateGraph 두 노드 구조 참고 |
| MediaWiki TextExtracts | https://www.mediawiki.org/wiki/Extension:TextExtracts | 본문 추출 API 참고 |

위키 본문은 실행 시 로컬 .runtime에 캐시되며 제출 ZIP에서는 제외한다. 데이터 요약은 원문 전체를 재현하지 않으며 구단·시즌 자체의 기록 사실만 담았다. 연고 도시는 시즌 메타데이터의 수작업 분류로 입력했고 세부 홈구장·제2구장 정보는 제공하지 않는다. 위키 자료를 별도로 재배포할 때에는 CC 조건을 확인하고 원문 이력 링크와 수집일·변경 내역을 추가한다. 최신 선수 이동·현재 순위로 사용하면 안 된다.
