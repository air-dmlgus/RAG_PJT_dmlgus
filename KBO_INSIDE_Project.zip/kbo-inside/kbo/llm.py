import json
from openai import OpenAI
class LLM:
    def __init__(self,cfg):
        cfg.require_key()
        self.cfg=cfg
        self.client = OpenAI(api_key=cfg.key,base_url=cfg.base_url,max_retries=cfg['retries'],timeout=45) if cfg.mode=='online' else None
    def text(self,system,payload):
        if not self.client: raise ValueError('온라인 생성에는 API 설정이 필요합니다.')
        r=self.client.chat.completions.create(model=self.cfg.chat_model,messages=[{'role':'system','content':system},{'role':'user','content':json.dumps(payload,ensure_ascii=False)}],temperature=0)
        return r.choices[0].message.content or ''
    def structured(self,system,payload,key):
        # JSON 형식 오류를 재질문하며, 파싱 실패를 빈 결과로 숨기지 않는다.
        for _ in range(2):
            raw=self.text(system,payload).strip()
            if raw.startswith('```'): raw=raw.split('\n',1)[1].rsplit('```',1)[0]
            try:
                result=json.loads(raw)[key]
                if isinstance(result,list) and all(isinstance(x,str) for x in result): return result
            except (ValueError,KeyError,TypeError): pass
        raise ValueError('모델의 구조화 출력 형식이 올바르지 않습니다. 다시 시도하세요.')
