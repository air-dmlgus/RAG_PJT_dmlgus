import re
from typing import TypedDict
from langgraph.graph import StateGraph,START,END
from .data import items
from .prompts import ANSWER,SELECT
class State(TypedDict,total=False):
    item:dict
    question:str
    method:str
    evidence:list
    answer:str
    used:list

def cited(answer,evidence):
    ids={int(x) for x in re.findall(r'\[근거 (\d+)\]',answer)}
    return [dict(e,number=i) for i,e in enumerate(evidence,1) if i in ids]
class RAG:
    def __init__(self,store):
        self.store=store;graph=StateGraph(State)
        graph.add_node('retrieve',self.retrieve);graph.add_node('generate',self.generate)
        graph.add_edge(START,'retrieve');graph.add_edge('retrieve','generate');graph.add_edge('generate',END)
        self.graph=graph.compile()
    def retrieve(self,state):
        item=state['item'];meta=self.store.meta.get(ids=[item['id']],include=['documents','metadatas'])
        if not meta['ids']:raise ValueError('메타데이터 색인이 없습니다. 먼저 색인하세요.')
        evidence=[{'id':meta['ids'][0],'text':meta['documents'][0],'metadata':meta['metadatas'][0]}]
        rows=self.store.query(self.store.docs,state['question'],self.store.cfg['top_k'],{'item_id':item['id']},state.get('method','similarity'))
        seen={e['text'] for e in evidence}
        for row in rows:
            if row['text'] not in seen:
                seen.add(row['text']);evidence.append({k:v for k,v in row.items() if k!='embedding'})
        return {'evidence':evidence}
    def generate(self,state):
        evidence=state['evidence'];question=state['question'];item=state['item']
        if self.store.cfg.mode=='online':
            answer=self.store.llm.text(ANSWER,{'item':item,'question':question,'evidence':[dict(e,number=i) for i,e in enumerate(evidence,1)]})
            # 존재하지 않는 근거 번호는 사실 확인 불가로 대체한다.
            answer=re.sub(r'\[근거 (\d+)\]',lambda m:m.group(0) if 1<=int(m[1])<=len(evidence) else '[존재하지 않는 근거]',answer)
            if '[존재하지 않는 근거]' in answer:answer='생성된 답변의 근거 번호를 검증하지 못했습니다. 다시 질문하세요.'
        else:
            if any(x in question for x in ['최종 순위','최종순위','입문','가이드']):
                answer=f"{item['name']}의 KBO 최종 순위는 {item['final_rank']}위입니다. [근거 1]"
                if '입문' in question or '가이드' in question:answer+='\n최종 순위는 정규시즌 순위와 다를 수 있습니다. [근거 2]' if len(evidence)>1 else ''
            else:answer='제공된 문서에서 확인되지 않습니다. 데모 모드는 최종 순위·입문 가이드만 발췌합니다.'
        return {'answer':answer,'used':cited(answer,evidence)}
    def ask(self,item,question,method='similarity'):
        return self.graph.invoke({'item':item,'question':question,'method':method})

def discover(store,condition):
    rows=store.query(store.meta,condition,30)
    if store.cfg.mode=='online':
        ids=store.llm.structured(SELECT,{'condition':condition,'candidates':[dict(id=r['id'],title=r['metadata']['name'],summary=r['text']) for r in rows]},'ids')
        return [r['metadata'] for r in rows if r['id'] in ids]
    # 데모는 명시적으로 지원하는 구조화 조건만; 모르는 조건은 임의 추천하지 않는다.
    pool=items();parsed=False
    years=re.findall(r'(?:19|20)\d{2}',condition)
    if years:pool=[x for x in pool if x['year'] in map(int,years)];parsed=True
    rank=re.search(r'(\d+)위',condition)
    if '우승' in condition:pool=[x for x in pool if x['final_rank']==1];parsed=True
    elif rank:pool=[x for x in pool if x['final_rank']==int(rank[1])];parsed=True
    cities=[c for c in {x['city'] for x in pool} if c in condition]
    if cities:pool=[x for x in pool if x['city'] in cities];parsed=True
    teams=[t for t in {x['team'] for x in pool} if t in condition]
    if teams:pool=[x for x in pool if x['team'] in teams];parsed=True
    return pool if parsed else []
