import hashlib,json,os,time
from pathlib import Path
from urllib.parse import quote
import requests
from .config import ROOT
from .data import bundled
from .prompts import SEARCH,SELECT
class Collector:
    def __init__(self,cfg,store):
        self.cfg=cfg;self.store=store
        self.cache=cfg.db/'queries';self.cache.mkdir(parents=True,exist_ok=True)
        self.session=requests.Session()
        self.session.headers['User-Agent']=os.getenv('WIKI_USER_AGENT','KBOInside-Educational/1.0 (set-your-contact-before-online-use)')
    def api(self,params):
        last=None
        for attempt in range(self.cfg['retries']):
            time.sleep(self.cfg['request_interval']*(2**attempt))
            try:
                r=self.session.get('https://ko.wikipedia.org/w/api.php',params=dict(action='query',format='json',**params),timeout=20)
                r.raise_for_status();data=r.json()
                if 'error' in data:raise ValueError('문서 API 응답 오류')
                return data
            except (requests.RequestException,ValueError) as e:last=e
        raise ValueError('위키백과 연결 실패. 제공 문서 모드로 전환할 수 있습니다.') from last
    def collect(self,item,question,status=lambda x:None,online=False):
        # 선택 항목 자체의 제공 문서는 길이·LLM 선별보다 항상 우선.
        own=[x for x in bundled() if x['item_id']==item['id']]
        self.store.index_docs(item['id'],own)
        report={'queries':[],'accepted':[x['title'] for x in own],'rejected':[],'cache_hits':0}
        if not online:return report
        if self.cfg.mode!='online':raise ValueError('온라인 문서 검색은 online 모드에서 사용하세요.')
        agent=self.session.headers['User-Agent']
        if 'set-your-contact' in agent:raise ValueError('.env의 WIKI_USER_AGENT에 실제 연락처를 먼저 설정하세요.')
        queries=self.store.llm.structured(SEARCH,{'item':item,'question':question},'queries')[:4]
        queries=list(dict.fromkeys([item['own_title'],*queries]));report['queries']=queries
        for query in queries:
            cache_id=hashlib.sha256(query.encode()).hexdigest()
            path=self.cache/(cache_id+'.json')
            status(f'자료 수집: {query}')
            if path.exists():
                chosen=json.loads(path.read_text());report['cache_hits']+=1
            else:
                hits=self.api({'list':'search','srsearch':query,'srlimit':5})['query']['search']
                candidates=[{'id':str(h['pageid']),'title':h['title'],'summary':h['snippet']} for h in hits]
                ids=self.store.llm.structured(SELECT,{'item':item,'question':question,'candidates':candidates},'ids') if candidates else []
                chosen=[]
                for h in candidates:
                    # 정확히 선택 항목 이름에 대응하는 원문도 무조건 포함.
                    if h['id'] not in ids and h['title']!=item['own_title']:
                        report['rejected'].append(h['title']);continue
                    pages=self.api({'pageids':h['id'],'prop':'extracts|info','explaintext':1,'inprop':'url'})['query']['pages']
                    p=pages[h['id']];text=p.get('extract','')
                    if not text:raise ValueError('선택한 외부 문서의 본문을 가져올 수 없습니다.')
                    chosen.append({'id':h['id'],'title':p['title'],'text':text,'source':p.get('fullurl','https://ko.wikipedia.org/wiki/'+quote(p['title'])),'source_type':'위키백과'})
                path.write_text(json.dumps(chosen,ensure_ascii=False),encoding='utf-8')
            if chosen:self.store.index_docs(item['id'],chosen)
            report['accepted'].extend(d['title'] for d in chosen)
        return report
