import json, os
from pathlib import Path
from dotenv import load_dotenv
ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')
class Config:
    def __init__(self):
        self.values = json.loads((ROOT/'settings.json').read_text())
        self.mode = os.getenv('KBO_MODE','demo')
        self.key = os.getenv('OPENAI_API_KEY','')
        self.chat_model = os.getenv('CHAT_MODEL','gpt-4o-mini')
        self.embed_model = os.getenv('EMBED_MODEL','text-embedding-3-small')
        self.base_url = os.getenv('OPENAI_BASE_URL','https://api.openai.com/v1')
        self.db = ROOT/'.runtime'/self.mode/self.embed_model.replace('/','_')
        if self.values['chunk_size'] <= self.values['chunk_overlap'] or self.values['chunk_overlap'] < 0:
            raise ValueError('chunk_overlap은 0 이상 chunk_size 미만이어야 합니다.')
    def __getitem__(self, key): return self.values[key]
    def require_key(self):
        if self.mode == 'online' and not self.key:
            raise ValueError('API 키가 없습니다. .env의 OPENAI_API_KEY를 설정하세요.')
