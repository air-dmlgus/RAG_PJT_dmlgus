import json
from .config import ROOT
def items(): return json.loads((ROOT/'data/items.json').read_text(encoding='utf-8'))
def bundled(): return json.loads((ROOT/'data/documents.json').read_text(encoding='utf-8'))
def item_text(item):
    return ' | '.join(f'{k}: {v}' for k,v in item.items())
