import hashlib, math
import chromadb
from .llm import LLM
from .data import item_text
from langchain_text_splitters import RecursiveCharacterTextSplitter

def cosine(a,b):
    return sum(x*y for x,y in zip(a,b))/(math.sqrt(sum(x*x for x in a))*math.sqrt(sum(y*y for y in b)) or 1)
def mmr(query, rows, k, weight):
    chosen=[];pool=list(rows)
    while pool and len(chosen)<k:
        score=lambda r: weight*cosine(query,r['embedding'])-(1-weight)*max((cosine(r['embedding'],s['embedding']) for s in chosen),default=0)
        best=max(pool,key=score);chosen.append(best);pool.remove(best)
    return chosen
class Store:
    def __init__(self,cfg):
        self.cfg=cfg; self.llm=LLM(cfg)
        self.client=chromadb.PersistentClient(path=str(cfg.db))
        self.meta=self.client.get_or_create_collection('kbo_meta',metadata={'hnsw:space':'cosine'},embedding_function=None)
        self.docs=self.client.get_or_create_collection('kbo_docs',metadata={'hnsw:space':'cosine'},embedding_function=None)
    def embed(self,texts):
        if self.cfg.mode=='online':
            return [x.embedding for x in self.llm.client.embeddings.create(model=self.cfg.embed_model,input=texts).data]
        # 재현 가능한 구조 검증용 문자 n-gram 해시. 의미 임베딩이 아니다.
        output=[]
        for text in texts:
            v=[0.0]*256
            for n in (1,2,3):
                for i in range(max(0,len(text)-n+1)):
                    h=int.from_bytes(hashlib.sha256(text[i:i+n].encode()).digest()[:4],'big');v[h%256]+=1
            norm=math.sqrt(sum(x*x for x in v)) or 1
            output.append([x/norm for x in v])
        return output
    def index_items(self,items):
        for start in range(0,len(items),40):
            batch=items[start:start+40];texts=[item_text(x) for x in batch]
            self.meta.upsert(ids=[x['id'] for x in batch],documents=texts,metadatas=[dict(x,source_type='항목 메타데이터',title=x['name'],item_id=x['id']) for x in batch],embeddings=self.embed(texts))
        return self.meta.count()
    def index_docs(self,item_id,documents):
        split=RecursiveCharacterTextSplitter(chunk_size=self.cfg['chunk_size'],chunk_overlap=self.cfg['chunk_overlap'])
        total=0
        for doc in documents:
            digest=hashlib.sha256(doc['source'].encode()).hexdigest()[:20]
            chunks=split.split_text(doc['text'])
            if not chunks: raise ValueError('본문이 빈 문서는 색인할 수 없습니다.')
            metadata=dict(item_id=item_id,doc_id=digest,title=doc['title'],source=doc['source'],source_type=doc['source_type'])
            # API 실패로 기존 문서를 잃지 않게 모든 임베딩 생성 후 갱신한다.
            vectors=[]
            for start in range(0,len(chunks),40):vectors.extend(self.embed(chunks[start:start+40]))
            ids=[f'{item_id}:{digest}:{i}' for i in range(len(chunks))]
            old=self.docs.get(where={'$and':[{'item_id':item_id},{'doc_id':digest}]})['ids']
            for start in range(0,len(chunks),40):
                batch=chunks[start:start+40]
                self.docs.upsert(ids=ids[start:start+40],documents=batch,metadatas=[metadata]*len(batch),embeddings=vectors[start:start+40])
            stale=list(set(old)-set(ids))
            if stale:self.docs.delete(ids=stale)
            total+=len(chunks)
        return total
    def query(self,collection,question,k,where=None,method='similarity'):
        if collection.count()==0:return []
        q=self.embed([question])[0]
        result=collection.query(query_embeddings=[q],n_results=min(collection.count(),self.cfg['fetch_k'] if method=='mmr' else k),where=where,include=['documents','metadatas','embeddings'])
        rows=[dict(id=id,text=text,metadata=meta,embedding=list(vec)) for id,text,meta,vec in zip(result['ids'][0],result['documents'][0],result['metadatas'][0],result['embeddings'][0])]
        return mmr(q,rows,k,self.cfg['mmr_lambda']) if method=='mmr' else rows[:k]
