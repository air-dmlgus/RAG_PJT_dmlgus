import argparse
from kbo.config import Config
from kbo.data import items
from kbo.store import Store
from kbo.collect import Collector
p=argparse.ArgumentParser();p.add_argument('--twice',action='store_true');args=p.parse_args()
s=Store(Config())
for run in range(2 if args.twice else 1):
    s.index_items(items())
    for item in items():Collector(s.cfg,s).collect(item,'',online=False)
    print({'run':run+1,'items':s.meta.count(),'docs':s.docs.count()})
