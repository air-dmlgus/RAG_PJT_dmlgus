import tempfile,unittest,hashlib
from unittest.mock import patch
from pathlib import Path
from kbo.config import Config
from kbo.data import items,bundled
from kbo.store import Store
from kbo.collect import Collector
from kbo.rag import RAG,cited,discover
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.cfg=Config();cls.cfg.mode='demo';cls.cfg.db=Path(cls.tmp.name)
  cls.s=Store(cls.cfg);cls.s.index_items(items());cls.it=next(x for x in items() if x['id']=='lg-2023');cls.c=Collector(cls.cfg,cls.s);cls.c.collect(cls.it,'')
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def test_100_unique_items(self):
  self.assertEqual(len(items()),100);self.assertEqual(len({x['id'] for x in items()}),100)
 def test_rank_permutations(self):
  for year in range(2015,2025):self.assertEqual(sorted(x['final_rank'] for x in items() if x['year']==year),list(range(1,11)))
 def test_historic_names(self):
  d={x['id']:x for x in items()};self.assertEqual(d['ssg-2020']['team'],'SK 와이번스');self.assertEqual(d['kiwoom-2018']['team'],'넥센 히어로즈')
 def test_idempotent_metadata(self):
  before=self.s.meta.count();self.s.index_items(items());self.assertEqual(before,self.s.meta.count())
 def test_own_document(self):self.assertTrue(self.s.docs.get(where={'item_id':self.it['id']})['ids'])
 def test_scope(self):
  other=next(x for x in items() if x['id']=='lg-2024');self.c.collect(other,'')
  a=set(self.s.docs.get(where={'item_id':self.it['id']})['ids']);b=set(self.s.docs.get(where={'item_id':other['id']})['ids']);self.assertFalse(a&b)
  for method in ['similarity','mmr']:
   result=self.s.query(self.s.docs,'순위',5,{'item_id':self.it['id']},method);self.assertTrue(all(x['metadata']['item_id']==self.it['id'] for x in result))
 def test_rechunk(self):
  doc=dict(bundled()[0],source='https://example.org/test',text='검증용 문서입니다. '*300)
  self.cfg.values.update(chunk_size=100,chunk_overlap=20);a=self.s.index_docs('test',[doc]);self.cfg.values.update(chunk_size=900,chunk_overlap=180);b=self.s.index_docs('test',[doc])
  self.assertGreater(a,b);self.assertEqual(len(self.s.docs.get(where={'item_id':'test'})['ids']),b)
 def test_graph(self):self.assertEqual(set(RAG(self.s).graph.get_graph().nodes),{'__start__','retrieve','generate','__end__'})
 def test_metadata_forced(self):self.assertEqual(RAG(self.s).ask(self.it,'최종 순위는?')['evidence'][0]['id'],self.it['id'])
 def test_unknown(self):
  r=RAG(self.s).ask(self.it,'2027년 연봉은 얼마야?');self.assertIn('확인되지',r['answer']);self.assertFalse(r['used'])
 def test_used_citations(self):self.assertEqual(len(cited('답 [근거 1]',[{'id':'a'},{'id':'b'}])),1)
 def test_conditions(self):self.assertEqual([x['id'] for x in discover(self.s,'2023년 우승 구단')],['lg-2023'])
 def test_cached_query(self):
  self.cfg.mode='online';self.c.session.headers['User-Agent']='KBOInside/1.0 (contact: teacher@example.org)'
  for q in [self.it['own_title'],'LG 2023']:(self.c.cache/(hashlib.sha256(q.encode()).hexdigest()+'.json')).write_text('[]')
  try:
   with patch.object(self.s,'index_docs'),patch.object(self.s.llm,'structured',return_value=['LG 2023']),patch.object(self.c,'api',side_effect=AssertionError('network should not run')):
    self.assertEqual(self.c.collect(self.it,'질문',online=True)['cache_hits'],2)
  finally:self.cfg.mode='demo'
 def test_missing_key(self):
  c=Config();c.mode='online';c.key=''
  with self.assertRaises(ValueError):c.require_key()
if __name__=='__main__':unittest.main(verbosity=2)
